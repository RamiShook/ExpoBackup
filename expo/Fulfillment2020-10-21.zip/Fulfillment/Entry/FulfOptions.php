<a href='#' class="mdl-navigation__link" id="usern" disabled><?php chkss() ?></a>
        <!--  index.php?profile  -->
          <a class="mdl-navigation__link" href="../BrowseAll.php">Browse All Products.</a>
          <a class="mdl-navigation__link" href="../BrowseAvailable.php">Browse Available Products.</a>
          <a class="mdl-navigation__link" href="../Fulfillment.php">Show Order's.</a>
          <a class="mdl-navigation__link" href="../Requests.php">Show Return/Replacement Requests.</a>
          <a class="mdl-navigation__link" href="../Entry/DataEntry.php">Enter New Product.</a>
              <a class="mdl-navigation__link" href="../ProductsEdit.php">Show/Edit Product's.</a>
                        <a class="mdl-navigation__link" href="../LastetProducts.php">Show/Edit Last 24h Product's.</a>
                        <a class="mdl-navigation__link" href="./AddQuantity.php">Add Quantity To Existing Product.</a>
                        <a class="mdl-navigation__link" href="./ChangePrice.php">Change Product Price.</a>


          <a class="mdl-navigation__link" href="../../index.php?logout" >logout.</a>

